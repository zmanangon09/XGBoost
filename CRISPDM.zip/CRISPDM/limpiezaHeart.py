import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import sys

# Forzar encoding UTF-8 para salida en consola
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# Configuracion visual
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 7)
plt.rcParams['font.size'] = 10

# ==========================================
# 1. CARGA DE DATOS
# ==========================================
print("="*60)
print("INICIANDO ANALISIS DE DATOS CARDIACOS")
print("="*60)

try:
    df = pd.read_csv('heart.csv')
    print(f"[OK] Dataset cargado: {df.shape[0]} filas x {df.shape[1]} columnas")
    print(f"[OK] Columnas: {list(df.columns)}")
except FileNotFoundError:
    print("[ERROR] Archivo 'heart.csv' no encontrado")
    exit()

# Backup del dataset original
df_original = df.copy()

# ==========================================
# 2. ANALISIS INICIAL
# ==========================================
print("\n" + "="*60)
print("ANALISIS EXPLORATORIO INICIAL")
print("="*60)

print("\n--- Informacion General ---")
df.info()

print("\n--- Estadisticas Descriptivas ---")
print(df.describe())

print("\n--- Primeras 5 filas ---")
print(df.head())

# ==========================================
# 3. LIMPIEZA DE DATOS
# ==========================================
print("\n" + "="*60)
print("FASE DE LIMPIEZA DE DATOS")
print("="*60)

# 3.1 DUPLICADOS
print("\n[PASO 1] Deteccion de duplicados...")
duplicados = df.duplicated().sum()
print(f"   Duplicados encontrados: {duplicados}")
if duplicados > 0:
    df = df.drop_duplicates()
    print(f"   [OK] {duplicados} duplicados eliminados")

# 3.2 VALORES NULOS
print("\n[PASO 2] Deteccion de valores nulos...")
nulos = df.isnull().sum()
if nulos.sum() > 0:
    print(f"   Valores nulos por columna:\n{nulos[nulos > 0]}")
else:
    print("   [OK] No se encontraron valores nulos")

# 3.3 VALIDACION DE RANGOS MEDICOS
print("\n[PASO 3] Validacion de rangos clinicos...")

# 3.3.1 EDAD (tipicamente 28-77 anios en este dataset)
edad_fuera = df[(df['Age'] < 18) | (df['Age'] > 120)].shape[0]
print(f"   Edad: {edad_fuera} valores fuera de rango [18-120]")
if edad_fuera > 0:
    df = df[(df['Age'] >= 18) & (df['Age'] <= 120)]

# 3.3.2 PRESION ARTERIAL EN REPOSO (90-200 mm Hg)
# Valores de 0 son errores de medicion
bp_ceros = df[df['RestingBP'] == 0].shape[0]
bp_anormal = df[(df['RestingBP'] < 80) | (df['RestingBP'] > 200)].shape[0]
print(f"   RestingBP: {bp_ceros} valores = 0, {bp_anormal} valores anormales")

if bp_ceros > 0:
    mediana_bp = df[df['RestingBP'] > 0]['RestingBP'].median()
    df.loc[df['RestingBP'] == 0, 'RestingBP'] = mediana_bp
    print(f"   [OK] Valores 0 reemplazados por mediana: {mediana_bp:.1f}")

# Eliminar outliers extremos
df = df[(df['RestingBP'] >= 80) & (df['RestingBP'] <= 200)]

# 3.3.3 COLESTEROL (125-564 mm/dl tipicamente)
# Valores de 0 son errores de laboratorio
col_ceros = df[df['Cholesterol'] == 0].shape[0]
print(f"   Cholesterol: {col_ceros} valores = 0 (error de medicion)")

if col_ceros > 0:
    # Calcular mediana solo de valores validos
    mediana_col = df[df['Cholesterol'] > 0]['Cholesterol'].median()
    df.loc[df['Cholesterol'] == 0, 'Cholesterol'] = mediana_col
    print(f"   [OK] Valores 0 reemplazados por mediana: {mediana_col:.1f}")

# 3.3.4 FRECUENCIA CARDIACA MAXIMA (60-202 bpm)
maxhr_fuera = df[(df['MaxHR'] < 60) | (df['MaxHR'] > 202)].shape[0]
print(f"   MaxHR: {maxhr_fuera} valores fuera de rango [60-202]")
df = df[(df['MaxHR'] >= 60) & (df['MaxHR'] <= 202)]

# 3.3.5 OLDPEAK (debe ser >= 0, tipicamente < 6)
oldpeak_negativo = df[df['Oldpeak'] < 0].shape[0]
print(f"   Oldpeak: {oldpeak_negativo} valores negativos")
df = df[df['Oldpeak'] >= 0]

# 3.4 VERIFICACION DE CATEGORIAS
print("\n[PASO 4] Verificacion de variables categoricas...")
categoricas = {
    'Sex': ['M', 'F'],
    'ChestPainType': ['TA', 'ATA', 'NAP', 'ASY'],
    'FastingBS': [0, 1],
    'RestingECG': ['Normal', 'ST', 'LVH'],
    'ExerciseAngina': ['Y', 'N'],
    'ST_Slope': ['Up', 'Flat', 'Down'],
    'HeartDisease': [0, 1]
}

for col, valores_validos in categoricas.items():
    valores_invalidos = df[~df[col].isin(valores_validos)].shape[0]
    if valores_invalidos > 0:
        print(f"   {col}: {valores_invalidos} valores invalidos encontrados")
        df = df[df[col].isin(valores_validos)]
    else:
        print(f"   [OK] {col}: Todos los valores son validos")

# ==========================================
# 4. RESUMEN DE LIMPIEZA
# ==========================================
print("\n" + "="*60)
print("RESUMEN DE LIMPIEZA")
print("="*60)
print(f"Filas originales:  {df_original.shape[0]}")
print(f"Filas limpiadas:   {df.shape[0]}")
print(f"Filas eliminadas:  {df_original.shape[0] - df.shape[0]} ({((df_original.shape[0] - df.shape[0])/df_original.shape[0]*100):.2f}%)")
print(f"Columnas:          {df.shape[1]}")

# ==========================================
# 5. EXPORTAR DATASET LIMPIO
# ==========================================
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
nombre_archivo = f'heart_cleaned_{timestamp}.csv'
df.to_csv(nombre_archivo, index=False)
print(f"\n[OK] Dataset limpio exportado: {nombre_archivo}")

# Tambien crear version sin timestamp para facil acceso
df.to_csv('heart_cleaned.csv', index=False)
print(f"[OK] Copia adicional: heart_cleaned.csv")

# ==========================================
# 6. ANALISIS EXPLORATORIO DE DATOS (EDA)
# ==========================================
print("\n" + "="*60)
print("GENERANDO GRAFICAS EXPLORATORIAS")
print("="*60)

# GRAFICA 1: DISTRIBUCION DE LA VARIABLE OBJETIVO
fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Pie chart
conteo = df['HeartDisease'].value_counts()
explode = [0, 0.1]
colors = ['#66b3ff', '#ff6b6b']
axes[0].pie(conteo, labels=['Sano (0)', 'Enfermo (1)'], autopct='%1.1f%%', 
           colors=colors, explode=explode, shadow=True, startangle=90)
axes[0].set_title('Distribucion de Diagnosticos', fontsize=14, fontweight='bold')

# Bar chart con numeros
sns.countplot(x='HeartDisease', data=df, palette=colors, ax=axes[1])
axes[1].set_title('Conteo de Casos', fontsize=14, fontweight='bold')
axes[1].set_xlabel('Diagnostico')
axes[1].set_ylabel('Cantidad')
axes[1].set_xticklabels(['Sano', 'Enfermo'])
for p in axes[1].patches:
    axes[1].annotate(f'{int(p.get_height())}', 
                    (p.get_x() + p.get_width()/2., p.get_height()),
                    ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.tight_layout()
plt.savefig('01_distribucion_objetivo.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 1 guardada: 01_distribucion_objetivo.png")
plt.show()

# GRAFICA 2: VARIABLES NUMERICAS (HISTOGRAMAS)
columnas_numericas = ['Age', 'RestingBP', 'Cholesterol', 'MaxHR', 'Oldpeak']
fig, axes = plt.subplots(2, 3, figsize=(15, 10))
axes = axes.flatten()

for i, col in enumerate(columnas_numericas):
    axes[i].hist(df[col], bins=30, color='#3498db', edgecolor='black', alpha=0.7)
    axes[i].set_title(f'{col}', fontsize=12, fontweight='bold')
    axes[i].set_xlabel('Valor')
    axes[i].set_ylabel('Frecuencia')
    axes[i].axvline(df[col].mean(), color='red', linestyle='--', 
                   linewidth=2, label=f'Media: {df[col].mean():.1f}')
    axes[i].legend()
    axes[i].grid(alpha=0.3)

axes[5].axis('off')  # Ocultar el ultimo subplot vacio
plt.suptitle('Distribucion de Variables Numericas', fontsize=16, fontweight='bold', y=1.00)
plt.tight_layout()
plt.savefig('02_histogramas_numericas.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 2 guardada: 02_histogramas_numericas.png")
plt.show()

# GRAFICA 3: VARIABLES CATEGORICAS VS ENFERMEDAD
categoricas_plot = ['Sex', 'ChestPainType', 'ExerciseAngina', 'ST_Slope']
fig, axes = plt.subplots(2, 2, figsize=(16, 12))
axes = axes.flatten()

for i, col in enumerate(categoricas_plot):
    sns.countplot(x=col, hue='HeartDisease', data=df, palette='Set2', ax=axes[i])
    axes[i].set_title(f'{col} vs Enfermedad Cardiaca', fontsize=12, fontweight='bold')
    axes[i].set_xlabel(col)
    axes[i].set_ylabel('Cantidad')
    axes[i].legend(title='Diagnostico', labels=['Sano', 'Enfermo'])
    
    # Anadir valores en las barras
    for p in axes[i].patches:
        height = p.get_height()
        if height > 0:
            axes[i].annotate(f'{int(height)}',
                           (p.get_x() + p.get_width()/2., height),
                           ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('03_categoricas_vs_enfermedad.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 3 guardada: 03_categoricas_vs_enfermedad.png")
plt.show()

# GRAFICA 4: MATRIZ DE CORRELACION
df_encoded = pd.get_dummies(df, drop_first=True, columns=['Sex', 'ChestPainType', 
                             'RestingECG', 'ExerciseAngina', 'ST_Slope'])
plt.figure(figsize=(16, 14))
correlacion = df_encoded.corr()
mask = np.triu(np.ones_like(correlacion, dtype=bool))
sns.heatmap(correlacion, mask=mask, annot=False, cmap='coolwarm', 
            linewidths=0.5, center=0, vmin=-1, vmax=1, square=True)
plt.title('Matriz de Correlaciones (Variables Codificadas)', 
         fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('04_matriz_correlacion.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 4 guardada: 04_matriz_correlacion.png")
plt.show()

# GRAFICA 5: RELACIONES CLAVE
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 5.1 Edad vs MaxHR
sns.scatterplot(x='Age', y='MaxHR', hue='HeartDisease', data=df, 
               palette='seismic', alpha=0.6, s=50, ax=axes[0, 0])
axes[0, 0].set_title('Edad vs Frecuencia Cardiaca Maxima', fontweight='bold')
axes[0, 0].legend(title='Diagnostico', labels=['Sano', 'Enfermo'])

# 5.2 Colesterol vs MaxHR
sns.scatterplot(x='Cholesterol', y='MaxHR', hue='HeartDisease', data=df,
               palette='viridis', alpha=0.6, s=50, ax=axes[0, 1])
axes[0, 1].set_title('Colesterol vs Frecuencia Cardiaca Maxima', fontweight='bold')
axes[0, 1].legend(title='Diagnostico', labels=['Sano', 'Enfermo'])

# 5.3 Edad por Sexo
sns.violinplot(x='Sex', y='Age', hue='HeartDisease', data=df, 
              palette='muted', split=True, ax=axes[1, 0])
axes[1, 0].set_title('Distribucion de Edad por Sexo', fontweight='bold')
axes[1, 0].set_xticklabels(['Femenino', 'Masculino'])
axes[1, 0].legend(title='Diagnostico', labels=['Sano', 'Enfermo'])

# 5.4 RestingBP vs Cholesterol
sns.scatterplot(x='RestingBP', y='Cholesterol', hue='HeartDisease', 
               data=df, palette='coolwarm', alpha=0.6, s=50, ax=axes[1, 1])
axes[1, 1].set_title('Presion Arterial vs Colesterol', fontweight='bold')
axes[1, 1].legend(title='Diagnostico', labels=['Sano', 'Enfermo'])

plt.tight_layout()
plt.savefig('05_relaciones_clave.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 5 guardada: 05_relaciones_clave.png")
plt.show()

# GRAFICA 6: BOXPLOTS COMPARATIVOS
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
axes = axes.flatten()

for i, col in enumerate(columnas_numericas):
    sns.boxplot(x='HeartDisease', y=col, data=df, palette='Set2', ax=axes[i])
    axes[i].set_title(f'{col} por Diagnostico', fontweight='bold')
    axes[i].set_xticklabels(['Sano', 'Enfermo'])
    axes[i].set_xlabel('Diagnostico')

axes[5].axis('off')
plt.suptitle('Comparacion de Variables Numericas por Diagnostico', 
            fontsize=16, fontweight='bold')
plt.tight_layout()
plt.savefig('06_boxplots_comparativos.png', dpi=300, bbox_inches='tight')
print("[OK] Grafica 6 guardada: 06_boxplots_comparativos.png")
plt.show()

# ==========================================
# 7. ESTADISTICAS FINALES
# ==========================================
print("\n" + "="*60)
print("ESTADISTICAS DEL DATASET LIMPIO")
print("="*60)

print("\n--- Distribucion de Diagnosticos ---")
print(df['HeartDisease'].value_counts())
print(f"\nBalance de clases: {(df['HeartDisease'].value_counts()[1] / len(df) * 100):.1f}% enfermos")

print("\n--- Estadisticas por Grupo ---")
print("\nEdad promedio:")
print(df.groupby('HeartDisease')['Age'].mean())

print("\nColesterol promedio:")
print(df.groupby('HeartDisease')['Cholesterol'].mean())

print("\n" + "="*60)
print("PROCESO COMPLETADO EXITOSAMENTE")
print("="*60)
print(f"\n[OK] Dataset limpio: heart_cleaned.csv")
print(f"[OK] Total de graficas generadas: 6")
print(f"[OK] Datos listos para modelado")