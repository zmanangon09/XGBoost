from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import xgboost as xgb
import joblib
import numpy as np

app = Flask(__name__)
CORS(app)  # Permite que React se comunique con este servidor

# --- CARGAR MODELO Y COLUMNAS ---
model = xgb.XGBClassifier()
model.load_model("modelo_cardiaco_xgb.json")
model_columns = joblib.load("columnas_modelo.pkl")

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    
    # 1. Convertir JSON a DataFrame
    input_data = {
        'Age': [float(data['Age'])],
        'Sex': [data['Sex']],
        'ChestPainType': [data['ChestPainType']],
        'RestingBP': [float(data['RestingBP'])],
        'Cholesterol': [float(data['Cholesterol'])],
        'FastingBS': [int(data['FastingBS'])],
        'RestingECG': [data['RestingECG']],
        'MaxHR': [float(data['MaxHR'])],
        'ExerciseAngina': [data['ExerciseAngina']],
        'Oldpeak': [float(data['Oldpeak'])],
        'ST_Slope': [data['ST_Slope']]
    }
    df = pd.DataFrame(input_data)

    # 2. Ingeniería de Variables (IGUAL QUE EN TU ENTRENAMIENTO)
    df['HeartRate_Age_Ratio'] = df['MaxHR'] / df['Age']

    # 3. Preprocesamiento (One-Hot Encoding manual para coincidir con el modelo)
    # Creamos un DataFrame vacío con las columnas exactas del modelo, lleno de ceros
    df_processed = pd.DataFrame(0, index=[0], columns=model_columns)

    # Llenamos las variables numéricas directas
    numeric_cols = ['Age', 'RestingBP', 'Cholesterol', 'FastingBS', 'MaxHR', 'Oldpeak', 'HeartRate_Age_Ratio']
    for col in numeric_cols:
        if col in df_processed.columns:
            df_processed[col] = df[col]

    # Llenamos las categóricas (Simulando get_dummies)
    # Ejemplo: Si Sex es 'M', activamos la columna 'Sex_M' si existe
    if 'Sex_M' in model_columns and data['Sex'] == 'M': df_processed['Sex_M'] = 1
    
    # ChestPainType
    val = data['ChestPainType']
    if f'ChestPainType_{val}' in model_columns: df_processed[f'ChestPainType_{val}'] = 1

    # RestingECG
    val = data['RestingECG']
    if f'RestingECG_{val}' in model_columns: df_processed[f'RestingECG_{val}'] = 1

    # ExerciseAngina
    if 'ExerciseAngina_Y' in model_columns and data['ExerciseAngina'] == 'Y': df_processed['ExerciseAngina_Y'] = 1
    
    # ST_Slope
    val = data['ST_Slope']
    if f'ST_Slope_{val}' in model_columns: df_processed[f'ST_Slope_{val}'] = 1

    # 4. Predicción
    prediction = model.predict(df_processed)[0]
    probability = model.predict_proba(df_processed)[0][1]

    return jsonify({
        'prediction': int(prediction),
        'probability': float(probability) * 100
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)