import React, { useState } from 'react';
import './App.css';

function App() {
  const [formData, setFormData] = useState({
    Age: '', Sex: 'M', ChestPainType: 'ASY', RestingBP: '',
    Cholesterol: '', FastingBS: '0', RestingECG: 'Normal',
    MaxHR: '', ExerciseAngina: 'N', Oldpeak: '', ST_Slope: 'Flat'
  });

  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error("Error:", error);
      alert("Error al conectar con el servidor médico.");
    }
    setLoading(false);
  };

  return (
    <div className="container">
      <h1>🩺 Sistema de Diagnóstico Cardíaco IA</h1>
      <p style={{textAlign: 'center', color: '#64748b', marginBottom: '20px'}}>
        Ingrese los parámetros clínicos del paciente para evaluar riesgo cardiovascular mediante XGBoost.
      </p>
      
      <form onSubmit={handleSubmit} className="medical-form">
        <div className="form-group">
          <label htmlFor="Age">Edad (Años)</label>
          <input id="Age" type="number" name="Age" required onChange={handleChange} placeholder="Ej: 55" />
        </div>

        <div className="form-group">
          <label htmlFor="Sex">Sexo Biológico</label>
          <select id="Sex" name="Sex" onChange={handleChange}>
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="ChestPainType">Tipo de Dolor Torácico</label>
          <select id="ChestPainType" name="ChestPainType" onChange={handleChange}>
            <option value="ASY">Asintomático (ASY)</option>
            <option value="NAP">Dolor No Anginoso (NAP)</option>
            <option value="ATA">Angina Atípica (ATA)</option>
            <option value="TA">Angina Típica (TA)</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="RestingBP">Presión Arterial en Reposo (mm Hg)</label>
          <input id="RestingBP" type="number" name="RestingBP" required onChange={handleChange} placeholder="Ej: 140" />
        </div>

        <div className="form-group">
          <label htmlFor="Cholesterol">Colesterol Sérico (mm/dl)</label>
          <input id="Cholesterol" type="number" name="Cholesterol" required onChange={handleChange} placeholder="Ej: 289" />
        </div>

        <div className="form-group">
          <label htmlFor="FastingBS">Glucemia en Ayunas &gt; 120 mg/dl</label>
          <select id="FastingBS" name="FastingBS" onChange={handleChange}>
            <option value="0">No (Normal)</option>
            <option value="1">Sí (Elevada)</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="RestingECG">Electrocardiograma en Reposo</label>
          <select id="RestingECG" name="RestingECG" onChange={handleChange}>
            <option value="Normal">Normal</option>
            <option value="LVH">Hipertrofia Ventricular Izq.</option>
            <option value="ST">Anormalidad Onda ST-T</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="MaxHR">Frecuencia Cardíaca Máxima</label>
          <input id="MaxHR" type="number" name="MaxHR" required onChange={handleChange} placeholder="Ej: 172" />
        </div>

        <div className="form-group">
          <label htmlFor="ExerciseAngina">Angina Inducida por Ejercicio</label>
          <select id="ExerciseAngina" name="ExerciseAngina" onChange={handleChange}>
            <option value="N">No</option>
            <option value="Y">Sí</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="Oldpeak">Depresión ST (Oldpeak)</label>
          <input id="Oldpeak" type="number" step="0.1" name="Oldpeak" required onChange={handleChange} placeholder="Ej: 1.5" />
        </div>

        <div className="form-group">
          <label htmlFor="ST_Slope">Pendiente Segmento ST</label>
          <select id="ST_Slope" name="ST_Slope" onChange={handleChange}>
            <option value="Flat">Plana (Flat)</option>
            <option value="Up">Ascendente (Up)</option>
            <option value="Down">Descendente (Down)</option>
          </select>
        </div>

        <button type="submit" className="submit-btn" disabled={loading}>
          {loading ? "Analizando..." : "CALCULAR RIESGO CLÍNICO"}
        </button>
      </form>

      {result && (
        <div className={`result-container ${result.prediction === 1 ? 'result-danger' : 'result-safe'}`}>
          <h2>
            {result.prediction === 1 
              ? "⚠️ ALTO RIESGO DETECTADO" 
              : "✅ BAJO RIESGO DETECTADO"}
          </h2>
          <p>Probabilidad estimada por el modelo:</p>
          <div style={{fontSize: '2rem', fontWeight: 'bold'}}>
            {result.probability.toFixed(2)}%
          </div>
          {result.prediction === 1 && (
            <div className="probability-bar">
              <div className="probability-fill" style={{width: `${result.probability}%`}}></div>
            </div>
          )}
          <p style={{marginTop: '15px', fontSize: '0.9rem'}}>
            *Este resultado es una predicción auxiliar basada en IA y no sustituye el diagnóstico médico profesional.
          </p>
        </div>
      )}
    </div>
  );
}

export default App;